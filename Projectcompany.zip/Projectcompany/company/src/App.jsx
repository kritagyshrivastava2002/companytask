
import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import OtpVerification from './page/OtpVerification'
import Login from './page/login'
import SignUp from './page/Signup'
import ChangePassword from './page/ChangePassword'
import ForgotPassword from './page/ForgotPassword'
import Navbar from './components/Navbar'
import AdmissionForm from './components/AdmissionForm';


function App() {

  return(
    <Router>
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/otp-verification" element={<OtpVerification />} />
    </Routes>
  </Router>
  );
};

export default App
