import React, { useState } from 'react';

const ChangePassword = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setconfirmPassword] = useState('')


  const handleSave = (e) => {
    e.preventDefault();
    if (password.length < 8) {
      alert('Password must be at least 8 characters long.');
      return;
    }
    else if (password !== confirmPassword) {
        alert('password do not match')
        
    } else
    console.log('Password changed to:', password);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
      <div className="flex justify-center mb-4">
          <img
            src="https://s3-alpha-sig.figma.com/img/e301/e9c9/53dbd57815857c13a1ccdc265e6de37b?Expires=1746403200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=KxESYVmnShqBwK7q0RRxtlvI9jHZQZGFCDPZDTib-MAqvTe2oi~r5B298iqoeFrGaAbMxOKqMUSRjuRnX0y9QI7g0T-p8vpd~ZOcq9H-yl6fLsiD73r8p~L5poC8iv5LxkpuqNco9xDUh92GySZZ~qomHKCeaaoo7RG8EQQBDwy3vZ~6JY1LkcEfs2SYe2BXSUTj2UyALzfpTP942lutbbA8N65zmZgheDJMMDGqaxU-izcAQfBnvJIprP7EFyoiOAUiLkUykeAAEx96tfyi0cu2l22vaEwGF~mhhORpZpwwxHMMv9VhNGwFQi~FBpsYd0kwP3Sh10ffHrVYX3mAxw__" 
            alt="Logo"
            className="h-12 w-auto"
          />
        </div>
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-6">Change Password</h2>

        <form onSubmit={handleSave}>
          <div className="mb-4">
            <label htmlFor="newPassword" className="block text-gray-700 font-semibold mb-2">
              New Password
            </label>
            <input
              type="password"
              id="newPassword"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <p className="text-sm text-gray-500 mb-6">
         <span className="font-medium"> Your password must have at least 8 characters and should include a combination of number letter and special characters(!@#$%)</span>.
          </p>

          <div className="mb-4">
            <label htmlFor="newPassword" className="block text-gray-700 font-semibold mb-2">
              Confirm Password
            </label>
            <input
              type="password"
              id="newPassword"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={confirmPassword}
              onChange={(e) => setconfirmPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200"
          >
            Save
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChangePassword;
