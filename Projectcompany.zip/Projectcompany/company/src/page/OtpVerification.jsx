import React, { useState, useRef, useEffect } from 'react';

const OtpVerification = () => {
  const [otp, setOtp] = useState(new Array(6).fill(''));
  const inputRefs = useRef([]);
  const [timer, setTimer] = useState(20);
  const [resendAvailable, setResendAvailable] = useState(false);

  useEffect(() => {
    const countdown = setInterval(() => {
      setTimer((prev) => {
        if (prev === 1) {
          clearInterval(countdown);
          setResendAvailable(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(countdown);
  }, []);

  const handleChange = (value, index) => {
    if (!/^[0-9a-zA-Z]?$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      inputRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  const handleResend = () => {
    setOtp(new Array(6).fill(''));
    setTimer(20);
    setResendAvailable(false);
    inputRefs.current[0].focus();
    console.log('Resending OTP...');
  };

  const handleSubmit = () => {
    const enteredOtp = otp.join('');
    console.log('Submitting OTP:', enteredOtp);
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md text-center">
        
        <div className="flex justify-center mb-4">
          <img
            src="https://s3-alpha-sig.figma.com/img/e301/e9c9/53dbd57815857c13a1ccdc265e6de37b?Expires=1746403200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=KxESYVmnShqBwK7q0RRxtlvI9jHZQZGFCDPZDTib-MAqvTe2oi~r5B298iqoeFrGaAbMxOKqMUSRjuRnX0y9QI7g0T-p8vpd~ZOcq9H-yl6fLsiD73r8p~L5poC8iv5LxkpuqNco9xDUh92GySZZ~qomHKCeaaoo7RG8EQQBDwy3vZ~6JY1LkcEfs2SYe2BXSUTj2UyALzfpTP942lutbbA8N65zmZgheDJMMDGqaxU-izcAQfBnvJIprP7EFyoiOAUiLkUykeAAEx96tfyi0cu2l22vaEwGF~mhhORpZpwwxHMMv9VhNGwFQi~FBpsYd0kwP3Sh10ffHrVYX3mAxw__" 
            alt="Logo"
            className="h-12 w-auto"
          />
        </div>

        <h2 className="text-2xl font-bold mb-4">OTP Verification</h2>
        <p className="text-sm text-gray-600 mb-6">
          We’ve sent a 6-digit to your Example@gmail.com. 
          Enter the code below to confirm account.
        </p>

        <div className="flex justify-between mb-6">
          {otp.map((value, index) => (
            <input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="password"
              maxLength={1}
              value={value}
              onChange={(e) => handleChange(e.target.value, index)}
              onKeyDown={(e) => handleKeyDown(e, index)}
              className="w-10 h-12 text-center border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 text-xl"
            />
          ))}
        </div>

        <div className="mb-4">
          {!resendAvailable ? (
            <p className="text-sm text-gray-600">
              Resend code in <span className="font-semibold">{timer}s</span>
            </p>
          ) : (
            <p className="text-sm text-gray-600">
              Didn’t receive the code?{' '}
              <button onClick={handleResend} className="text-blue-600 hover:underline font-medium">
                Resend
              </button>
            </p>
          )}
        </div>

        <button
          onClick={handleSubmit}
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200"
        >
          Send OTP
        </button>
      </div>
    </div>
  );
};

export default OtpVerification;
