import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ForgotPassword = () => {
  const [emailOrMobile, setEmailOrMobile] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate(); 

  const isValidEmail = (input) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input);
  const isValidMobile = (input) => /^[0-9]{10}$/.test(input);

  const handleSendOtp = (e) => {
    e.preventDefault();

    if (!isValidEmail(emailOrMobile) && !isValidMobile(emailOrMobile)) {
      setError('Please enter a valid email address or 10-digit mobile number.');
      return;
    }

    setError('');
    console.log('Sending OTP to:', emailOrMobile);

 
    navigate('/otp-verification');
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 px-4">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <div className="flex justify-center mb-4">
          <img
            src="https://s3-alpha-sig.figma.com/img/e301/e9c9/53dbd57815857c13a1ccdc265e6de37b?Expires=1746403200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=KxESYVmnShqBwK7q0RRxtlvI9jHZQZGFCDPZDTib-MAqvTe2oi~r5B298iqoeFrGaAbMxOKqMUSRjuRnX0y9QI7g0T-p8vpd~ZOcq9H-yl6fLsiD73r8p~L5poC8iv5LxkpuqNco9xDUh92GySZZ~qomHKCeaaoo7RG8EQQBDwy3vZ~6JY1LkcEfs2SYe2BXSUTj2UyALzfpTP942lutbbA8N65zmZgheDJMMDGqaxU-izcAQfBnvJIprP7EFyoiOAUiLkUykeAAEx96tfyi0cu2l22vaEwGF~mhhORpZpwwxHMMv9VhNGwFQi~FBpsYd0kwP3Sh10ffHrVYX3mAxw__"
            alt="Logo"
            className="h-12 w-auto"
          />
        </div>
        <h2 className="text-2xl font-bold text-center text-gray-800 mb-4">Forgot Your Password?</h2>
        <p className="text-sm text-gray-600 text-center mb-6">
          Enter your mobile number. We'll send you a code to reset your password.
        </p>

        <form onSubmit={handleSendOtp}>
          <div className="mb-4">
            <label htmlFor="emailOrMobile" className="block text-gray-700 font-semibold mb-2">
              Registered Email or Mobile
            </label>
            <input
              type="text"
              id="emailOrMobile"
              placeholder="Enter your email or mobile number"
              className={`w-full px-4 py-2 border ${error ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500`}
              value={emailOrMobile}
              onChange={(e) => setEmailOrMobile(e.target.value)}
              required
            />
            {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
          </div>

          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition duration-200"
          >
            Send OTP
          </button>
        </form>
      </div>
    </div>
  );
};

export default ForgotPassword;
