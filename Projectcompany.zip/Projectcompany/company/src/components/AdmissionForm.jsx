import React from 'react';

const AdmissionForm = () => {
  return (
    <div className="max-w-7xl mx-auto p-6 bg-white shadow-md rounded-lg mt-8">
      <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Admission Form</h2>
      <form className="space-y-6">

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

          <div>
            <label className="block font-medium text-gray-700 mb-1">Form Number</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Admission Number</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Name</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Class</label>
            <input type="text" placeholder='type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Date of Birth</label>
            <input type="date"  className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Gender</label>
            <select className="w-full border border-gray-300 px-3 py-2 rounded-md">
              <option value="">Select</option>
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Nationality</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Mother Tongue</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Religion</label>
            <input type="text" placeholder='type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Cast</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Blood Group</label>
            <select className="w-full border border-gray-300 px-3 py-2 rounded-md">
              <option value="">Select</option>
              <option>B+</option>
              <option>B-</option>
              <option>AB+</option>
              <option>AB-</option>
              <option>A+</option>
              <option>A-</option>
              <option>O+</option>
              <option>O-</option>
            </select>
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Aadhar Number</label>
            <input type="text" placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>

          <div>
            <label className="block font-medium text-gray-700 mb-1">Contact Number</label>
            <input type="text"placeholder='Type Here' className="w-full border border-gray-300 px-3 py-2 rounded-md" />
          </div>
        </div>

        <div className="text-center pt-4">
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition duration-200"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default AdmissionForm;
