import React from 'react';


const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
       
          <div className="flex-shrink-0">
            <h1 className="text-xl font-bold text-blue-600">MyLogo</h1>
          </div>

          <div className="hidden md:flex space-x-6 items-center">
            <a href="#home" className="text-gray-700 hover:text-blue-600 font-medium">
              Home
            </a>
            <a href="#gallery" className="text-gray-700 hover:text-blue-600 font-medium">
              Gallery
            </a>
            <a href="#teachers" className="text-gray-700 hover:text-blue-600 font-medium">
              Teachers
            </a>
            <a href="#contactus" className="text-gray-700 hover:text-blue-600 font-medium">
              Contact Us
            </a>
            <a href="#contactus" className="text-red-700 hover:text-blue-600 font-medium">
              Logout
              </a>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
