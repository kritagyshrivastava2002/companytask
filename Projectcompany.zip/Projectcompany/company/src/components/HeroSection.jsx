import React from "react";

const HeroSection = () => {
  return (
    <div
      className="relative bg-cover bg-center h-screen flex flex-col justify-center items-center text-white"
      style={{
        backgroundImage: "url('https://source.unsplash.com/1600x900/?university,campus')",
      }}
    >
      {/* Overlay for darker background */}
      <div className="absolute inset-0 bg-black opacity-60 z-0"></div>

      {/* Centered Content */}
      <div className="z-10 text-center px-4">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">
          Unlock Your Future with Easy Online Admission
        </h1>
        <div className="flex flex-col md:flex-row justify-center gap-4 mb-10">
          <button className="bg-blue-500 hover:bg-blue-600 px-6 py-3 rounded font-medium text-white">
            Apply Online
          </button>
          <button className="bg-green-500 hover:bg-green-600 px-6 py-3 rounded font-medium text-white">
            Explore More
          </button>
        </div>
      </div>

      {/* Bottom Logos */}
      <div className="absolute bottom-6 w-full z-10">
        <div className="flex justify-center items-center gap-8 flex-wrap px-4">
          {[...Array(5)].map((_, index) => (
            <div key={index} className="flex flex-col items-center text-sm text-center text-gray-200">
              <img
                src={`https://via.placeholder.com/60x60?text=Logo+${index + 1}`}
                alt={`Logo ${index + 1}`}
                className="h-14 w-14 object-contain mb-1"
              />
              <span>Partner {index + 1}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
